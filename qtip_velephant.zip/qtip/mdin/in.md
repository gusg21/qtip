title:Qtip:title

# Qtip: Static Site Generator

### Version Elephant


_You have successfully gotten qtip!_

This is an __example__ site. Most of the tags possible in markdown are here.

- - -

## About

### How to use

#### NOTE: Make sure you have [pandoc](http://pandoc.org/) installed and that it's up and running!!!

In the qtip folder, open mdin/in.md in your favorite text editor!  
When you're done adding text to your site, run generate.bat!  
Select your style. At the moment, there's only 2 - suggest more or submit your own on the issues page.  
Open index.html!

- - - 
 
### How to upload

You'll need to upload __two__ things. You'll want index.html in a folder and the core folder in there with it.

- - - 
 
### Hope you enjoy! [View on Github](http://github.com/gusg21)